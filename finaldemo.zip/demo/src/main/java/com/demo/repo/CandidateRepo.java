package com.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.entity.CandidateDetails;
import com.demo.entity.EmployeeDetails;


	public interface  CandidateRepo extends JpaRepository<CandidateDetails, Long>{
		
	public CandidateDetails findByCandId(EmployeeDetails employeeDetails);

	}


