package com.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.metadata.MethodType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.CandidateDetails;
import com.demo.entity.EmpDetails;
import com.demo.entity.EmployeeDetails;
import com.demo.entity.loginTable;
import com.demo.repo.CandidateRepo;
import com.demo.repo.UserRepository;
import com.demo.service.ServiceImpl;

@CrossOrigin(origins = "*", allowedHeaders = "*")

@RestController
public class UserController {
	

	@Autowired
	private UserRepository userRepo ;
	
    @Autowired
	private ServiceImpl service ;
	
	@Autowired
	private CandidateRepo repo;
	

	@PostMapping("/login")
	public void Login(@RequestBody loginTable login)
	{
     service.Login(login);
	}
	
    
 @RequestMapping(value="/getusername/{userName}",method =RequestMethod.GET)
       public String findByUsername(@PathVariable String userName) {
      
         loginTable userDetails = userRepo.findByUserName(userName);
           System.out.println(userDetails.getUserName());
           return userDetails.getUserName() ;
       }   
@PostMapping("/addCandidateFromL1")
public CandidateDetails addCandidate(@RequestBody EmployeeDetails emp) {
	CandidateDetails candidate=new CandidateDetails();
	candidate.setLevel("L1");
	candidate.setCandidateName(emp.getCandidateName());
	candidate.setSkill(emp.getSkill());
	candidate.setInterviewerId(emp.getIempcode());
	candidate.setInterviewerName(emp.getInterName());
	candidate.setDate(emp.getIdate());
	repo.save(candidate);
	return candidate;
	
}
@PostMapping("/addCandidateFromL2")
public CandidateDetails addCandidate1(@RequestBody EmpDetails emp) {
	CandidateDetails candidate=repo.findByCandId(emp.getCandId());
	
	if(candidate!=null) {
		candidate.setLevel("L2");
		repo.save(candidate);
		return candidate;
	}
	
	return null;
	
}
}




