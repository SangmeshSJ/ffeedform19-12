import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './components/home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { UserloginComponent } from './components/userlogin/userlogin.component';
import { FormComponent } from './components/form/form.component';
import { L1formComponent } from './components/l1form/l1form.component';
import { L2formComponent } from './components/l2form/l2form.component';
import { UseridComponent } from './components/userid/userid.component';
import { Level2Component } from './components/level2/level2.component';
import { from } from 'rxjs';
import { AdminComponent } from './components/admin/admin.component';
import { DemoComponent } from './Components/demo/demo.component';





@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    UserloginComponent,
    FormComponent,
    L1formComponent,
    L2formComponent,
    UseridComponent,
    Level2Component,
    AdminComponent,
    DemoComponent
    
   
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
