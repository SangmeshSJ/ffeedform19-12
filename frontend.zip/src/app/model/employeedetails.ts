import { Mode } from './mode';

export class EmployeeDetails{
    id: number; 
    candidateName: String;
    idate: String;
    interName: String;
    totalExp: String;
    releventExp: String;
    skill:String;
    mode:String;
    location:String;
    prating:String;
    crating:String;
    hirecomment:String;
    rcomment:String;
    hcomment:String;
    iempcode:number;
    esign:String;
    psdes1:String;
	bjdes2:String;
	kwdes:String;
	ta1:String;
    ta2:String;
    ta3:String;
    ides:String;
	cides:String;
	sdes:String;
	fdes:String;

	

}