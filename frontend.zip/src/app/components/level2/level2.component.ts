import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { EmpdetailsService } from 'src/app/service/empdetails.service';
import { EmployeedetailsService } from 'src/app/service/employeedetails.service';
import { EmployeeDetails } from 'src/app/model/employeedetails';


@Component({
  selector: 'app-level2',
  templateUrl: './level2.component.html',
  styleUrls: ['./level2.component.css']
})

export class Level2Component implements OnInit {

  Form: FormGroup;
  userID:number
  submitted:boolean= false;
  invalidLogin: boolean=false;
  employee:EmployeeDetails;
  constructor(private formBuilder: FormBuilder, private router: Router,private emp:EmployeedetailsService) { }

  
  ngOnInit() {
    this.Form = this.formBuilder.group({
      userid: ['', Validators.required]
      
  
    });
  }
  
  getEmpl(id:number){
this.emp.getEmployeeDetails(id).subscribe(res=>{
  this.employee=res;
  console.log(this.employee);
  console.log(res)
})
  }
  onSubmit() {
    this.submitted = true;
    localStorage.setItem("userid",this.Form.value.userid);
    // If validation failed, it should return 
    // to Validate again
    if (this.Form.invalid) {
    return;
    }
    console.log(this.Form.value)
    // this.Form.value=typeof this.userID
    this.router.navigate(['userid']);
    this.getEmpl(this.Form.value.userid)
    }
   
    


}
